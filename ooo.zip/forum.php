<?php
// Grace, Lena, Lamia og Christian
session_start();

if (empty($_SESSION['user']))

{
    header('Location:tilmelding.php');
    exit;
}
if (isset($_POST['submit'])) {
    if (file_exists("beskeder.txt")) {
        $string = file_get_contents("beskeder.txt");
        $beskeder = json_decode($string, true);

        header('Location:forsiden.php');
    }

    $besked = [
        "titel" => $_POST["titel"],
        "besked" => $_POST["besked"],
        "username" => $_POST["username"],
        $i =[
            "svar" =>$_POST ["svar"],
            "iusername" => $_POST ["iusername"],
            ]
    ];






    // flere parametre, altså svar til spørgsmålet

    //  [{"titel":"hej","besked":"med dig","username":"Hej123","svar fra andre brugere":{"første svar": "" }},{"titel":"1234","besked":"hej","username":"Hej123"}]

    $beskeder [] = $besked;
    $string = json_encode($beskeder);
    file_put_contents("beskeder.txt", $string);
}


?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="utf-8">
    <title></title>
</head>
<body>
  <header>
   <h1>Headbook</h1>



          <nav>
     <ul>
<li><a href="logud.php" class="forsidelinks"> Log ud </a></li>
<li><a href="tilmelding.php" class="forsidelinks"> Tilmeld/Login </a></li>
<li><a href="forum.php" class="forsidelinks"> Stil et spørgsmål </a></li>
</ul>

</nav>

</header>

<div class ="center">
<form action="" method="post">

    Titel
    <textarea name="titel" required></textarea>

    Spørgsmål
    <textarea name = "besked" required></textarea>
    <input type="submit" name="submit" class ="indsendknap">

    <input type="hidden" name="username" value=<?php echo $_SESSION['user']; ?> </input>

    <a href="forsiden.php" class="tilbagelink" > Tilbage til forside </a>


</form>
</div>


</body>
</html>
