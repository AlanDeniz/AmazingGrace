<?php
// Grace, Lena, Lamia og Christian
session_start();

// 1. If someone already logged in, redirect to secret page.
if (!empty($_SESSION['user']))
{
    header('Location:forsiden.php');
    exit;
}

// 1. Read existing users from a file (if it exists; else initialize to
//    empty array):
$user = [
    "username" => $_POST["username"],
    "password" => $_POST["password"],

];
if (file_exists("users.txt")) {
    $string = file_get_contents("users.txt");
    $users = json_decode($string, true);
}
foreach ($users as $user) {
    if ($_POST["username"] == $user["username"] &&
        $_POST["password"] == $user["password"]) {



// 2. Otherwise, if known user tried to log in, register her as
//    logged in and redirect to secret page.

        $_SESSION['user'] = $_POST['username'];
        header('Location:forsiden.php');
        exit;

    }

}
header('location:tilmelding.php');
?>
