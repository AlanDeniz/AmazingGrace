<?php
// Grace, Lena, Lamia og Christian
session_start();
session_destroy();

echo 'Du er nu logget ud. Du bliver automatisk sendt tilbage til forsiden!' ;

header('refresh: 3 forsiden.php');
exit;


?>
