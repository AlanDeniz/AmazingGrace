<?php
// Grace, Lena, Lamia og Christian
session_start();


    ?>


    <!DOCTYPE html>
    <html lang="en" dir="ltr">
    <head>
      <link rel="stylesheet" type="text/css" href="style.css">
      <style>

      </style>

        <meta charset="utf-8">
        <title></title>

    </head>
<body>
    <header>

     <h1>Headbook</h1>



            <nav>
       <ul>
  <li><a href="logud.php" class="forsidelinks"> Log ud </a></li>
  <li><a href="tilmelding.php" class="forsidelinks"> Tilmeld/Login </a></li>
  <li><a href="forum.php" class="forsidelinks"> Stil et spørgsmål </a></li>
  </ul>

  </nav>

  </header>



<?php
if (file_exists("beskeder.txt")) {
    $string = file_get_contents("beskeder.txt");
    $beskeder = json_decode($string, true);
}

$id = $_GET['id'];
$besked = $beskeder[$id];

foreach ($besked ["i"] as $a) {
echo "<br>";
echo "Svar: ";

    echo $a["svar"];
    echo "<br>";
    echo "Brugeren: ";


    echo $a["iusername"];
    echo "<br>";
    echo "<br>";


}
if (isset($_SESSION['user'])) {
  ?>
    <form action="save.php" method="GET">


  <!-- Her vi laver vores boks, til at svare. -->


        <input type="hidden" name="iusername" value=<?php echo $_SESSION['user']; ?> </input>
        <input type='hidden' name='id' value=<? echo $id; ?>>

        <textarea name="svar" placeholder="Skriv svar her" class ="svarboks"></textarea>
        <input type="submit" name="indsend" class ="indsendknap">

        <a href="forsiden.php" class="tilbagelink" > Tilbage til forside </a>


    </form>




<?php
}
?>

</body>
</html>
