
<!DOCTYPE html>
<!--Grace, Lena, Lamia og Christian-->
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">

    <title>Headbook</title>

    <link rel="stylesheet" type="text/css" href="style.css">


</head>


<header>
 <h1>Headbook</h1>



        <nav>

            <ul>
                <li><a href="logud.php" class="forsidelinks"> Log ud </a></li>
                <li><a href="tilmelding.php" class="forsidelinks"> Tilmeld/Login </a></li>
                <li><a href="forum.php" class = "forsidelinks"> Stil et spørgsmål </a></li>
            </ul>

    </nav>


</header>
<body>
  <h5> </h5>

<div id="velkommenbruger">
    <?php

    session_start();


    if (isset($_SESSION['user'])){
        echo "Velkommen ",
        $_SESSION ['user'] ;

    }

    if (file_exists("beskeder.txt")) {
        $string = file_get_contents("beskeder.txt");
        $beskeder = json_decode($string, true);

    }


    foreach ($beskeder as $i => $besked){
        echo "<ul>" ;
        echo "<a href='show.php?id=$i'>";
        echo "Titel:";
        echo $besked ["titel"];
        echo "<br>" ;
        echo "Spørgsmål:";
        echo  $besked['besked'];
        echo "<br>" ;
        echo "Bruger:";
        echo  $besked ["username"] ;
        echo "</a>" ;
        echo "</ul>" ;
    }

            ?>
</div>


</body>
</html>
