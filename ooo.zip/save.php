<?php
// Grace, Lena, Lamia og Christian
session_start();


  if (file_exists("beskeder.txt")) {
      $string = file_get_contents("beskeder.txt");
      $beskeder = json_decode($string, true);

  }


      $id = $_GET['id'];

$svar= $_GET['svar'];

$beskeder [$id]["i"][] = [
    "svar" =>$_GET["svar"],
    "iusername" => $_SESSION["user"],
];
    $string = json_encode($beskeder);
    file_put_contents("beskeder.txt", $string);

header('Location:forsiden.php');

?>
